import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ac.id.umn.crossmobile',
  appName: '25854_FajriYudhaPradana_Week10',
  webDir: 'build',
  bundledWebRuntime: false,
};

export default config;
