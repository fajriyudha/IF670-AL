package umn.ac.id.modul12;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
