package ac.id.umn.tigaduadelapanduatujuh.moduldelapan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
