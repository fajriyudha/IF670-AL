import path from 'path';

import { initializeApp } from 'firebase/app';
import { doc, collection, getDocs, getFirestore, query, setDoc } from 'firebase/firestore';
import { ref, getDownloadURL, uploadBytes, getStorage } from 'firebase/storage';
import { Memory } from '../data/memories-context';

const getApp = () =>
  initializeApp({
    apiKey: "AIzaSyA4KqZD1ElUqcNa1wQR9MsBGkyJj9YXjss",
    authDomain: "week11-df3ad.firebaseapp.com",
    projectId: "week11-df3ad",
    storageBucket: "week11-df3ad.appspot.com",
    messagingSenderId: "858043140779",
    appId: "1:858043140779:web:097f8af64564b7a86dc5ee"
  });

const firestore = () => getFirestore(getApp());

const storage = () => getStorage(getApp());

export const getMemories = async () => {
  const memories: Memory[] = [];

  try {
    const q = query(collection(firestore(), 'memories'));
    const snapshots = await getDocs(q);
    snapshots.forEach((doc) => memories.push(doc.data() as Memory));
  } catch (err) {
    throw err;
  }

  return memories;
};

export const createMemory = async (newMenu: Memory, file: File): Promise<Memory> => {
  const filename = `${Math.random()}.${path.extname(file.name)}`;

  // upload memory picture
  try {
    await uploadBytes(ref(storage(), `memories/${filename}`), file);
  } catch (err) {
    throw err;
  }

  // get upload url
  try {
    newMenu.imageUrl = await getDownloadURL(ref(storage(), `memories/${filename}`));
  } catch (err) {
    throw err;
  }

  // upload memory data
  try {
    await setDoc(doc(firestore(), 'memories', newMenu.id), newMenu);
  } catch (err) {
    throw err;
  }

  return newMenu;
};
